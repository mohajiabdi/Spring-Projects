package mohaji.Kindergarten_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KindergartenSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(KindergartenSystemApplication.class, args);
	}

}
